# Alura-challengeONE-Encriptador
Aplicación Web que permite encriptar texto.

Pagina desarrollada con tecnología HTML, CSS y JavaScript, cuya función es encriptar y desencriptar un texto, teniendo en consideración ciertas reglas a cumplir.

La aplicación forma parte del primer Challenge propuesto por Alura Latam para las capacitaciones presentes en el programa elaborado por Oracle Next Education (ONE).
